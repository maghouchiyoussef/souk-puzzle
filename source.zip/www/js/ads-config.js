// إعدادات AdMob — دابا IDs تجريبية ديال Google. غادي نبدلوهم ملي نصاوبو التطبيق فـ AdMob.
window.ADS_CONFIG = {
  TEST_MODE: true,
  BANNER_ID: 'ca-app-pub-3940256099942544/9214589741',
  INTERSTITIAL_ID: 'ca-app-pub-3940256099942544/1033173712',
  REWARDED_ID: 'ca-app-pub-3940256099942544/5224354917',
  INTERSTITIAL_EVERY_N_ROUNDS: 2,
};
