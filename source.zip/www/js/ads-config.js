// إعدادات AdMob ديال Souk Puzzle (IDs حقيقية).
// TEST_MODE: false = إعلانات حقيقية (نسخة النشر). لا تضغط على إعلاناتك أبدا.
window.ADS_CONFIG = {
  TEST_MODE: false,
  BANNER_ID: 'ca-app-pub-2986107222837015/4904575332',
  INTERSTITIAL_ID: 'ca-app-pub-2986107222837015/5806593462',
  REWARDED_ID: 'ca-app-pub-2986107222837015/8292407578',
  INTERSTITIAL_EVERY_N_ROUNDS: 2,
};
