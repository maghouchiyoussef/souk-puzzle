// كتالوج المجموعات والتصاور. زيد تصويرة جديدة: حطها فـ img/ وزيدها هنا.
window.CATALOG = [
  { id: 'zellige', icon: '🟦', color: '#1F4E8C',
    name: { ar: 'الزليج', fr: 'Zellige', en: 'Zellige' },
    images: [ { id: 'zellige-1', file: 'img/zellige-1.jpg', thumb: 'img/zellige-1-thumb.jpg' }, { id: 'zellige-2', file: 'img/zellige-2.jpg', thumb: 'img/zellige-2-thumb.jpg' }, { id: 'zellige-3', file: 'img/zellige-3.jpg', thumb: 'img/zellige-3-thumb.jpg' }, { id: 'zellige-4', file: 'img/zellige-4.jpg', thumb: 'img/zellige-4-thumb.jpg' }, { id: 'zellige-5', file: 'img/zellige-5.jpg', thumb: 'img/zellige-5-thumb.jpg' }, { id: 'zellige-6', file: 'img/zellige-6.jpg', thumb: 'img/zellige-6-thumb.jpg' }, { id: 'zellige-7', file: 'img/zellige-7.jpg', thumb: 'img/zellige-7-thumb.jpg' }, { id: 'zellige-8', file: 'img/zellige-8.jpg', thumb: 'img/zellige-8-thumb.jpg' }, { id: 'zellige-9', file: 'img/zellige-9.jpg', thumb: 'img/zellige-9-thumb.jpg' } ] },
  { id: 'carpets', icon: '🧶', color: '#8E2B23',
    name: { ar: 'الزرابي', fr: 'Tapis', en: 'Carpets' },
    images: [ { id: 'carpet-1', file: 'img/carpet-1.jpg', thumb: 'img/carpet-1-thumb.jpg' }, { id: 'carpet-2', file: 'img/carpet-2.jpg', thumb: 'img/carpet-2-thumb.jpg' }, { id: 'carpet-3', file: 'img/carpet-3.jpg', thumb: 'img/carpet-3-thumb.jpg' }, { id: 'carpet-4', file: 'img/carpet-4.jpg', thumb: 'img/carpet-4-thumb.jpg' }, { id: 'carpet-5', file: 'img/carpet-5.jpg', thumb: 'img/carpet-5-thumb.jpg' }, { id: 'carpet-6', file: 'img/carpet-6.jpg', thumb: 'img/carpet-6-thumb.jpg' }, { id: 'carpet-7', file: 'img/carpet-7.jpg', thumb: 'img/carpet-7-thumb.jpg' }, { id: 'carpet-8', file: 'img/carpet-8.jpg', thumb: 'img/carpet-8-thumb.jpg' } ] },
  { id: 'tajine', icon: '🏺', color: '#B5652B',
    name: { ar: 'الطاجين والفخار', fr: 'Tajines & poterie', en: 'Tajines & pottery' },
    images: [ { id: 'tajine-1', file: 'img/tajine-1.jpg', thumb: 'img/tajine-1-thumb.jpg' }, { id: 'tajine-2', file: 'img/tajine-2.jpg', thumb: 'img/tajine-2-thumb.jpg' }, { id: 'tajine-3', file: 'img/tajine-3.jpg', thumb: 'img/tajine-3-thumb.jpg' }, { id: 'tajine-4', file: 'img/tajine-4.jpg', thumb: 'img/tajine-4-thumb.jpg' }, { id: 'tajine-5', file: 'img/tajine-5.jpg', thumb: 'img/tajine-5-thumb.jpg' }, { id: 'tajine-6', file: 'img/tajine-6.jpg', thumb: 'img/tajine-6-thumb.jpg' }, { id: 'tajine-7', file: 'img/tajine-7.jpg', thumb: 'img/tajine-7-thumb.jpg' }, { id: 'tajine-8', file: 'img/tajine-8.jpg', thumb: 'img/tajine-8-thumb.jpg' } ] },
  { id: 'khanjar', icon: '🗡️', color: '#5B6770',
    name: { ar: 'الخنجر والنحاس', fr: 'Khanjar & cuivre', en: 'Khanjar & brass' },
    images: [ { id: 'khanjar-1', file: 'img/khanjar-1.jpg', thumb: 'img/khanjar-1-thumb.jpg' }, { id: 'khanjar-2', file: 'img/khanjar-2.jpg', thumb: 'img/khanjar-2-thumb.jpg' }, { id: 'khanjar-3', file: 'img/khanjar-3.jpg', thumb: 'img/khanjar-3-thumb.jpg' }, { id: 'khanjar-4', file: 'img/khanjar-4.jpg', thumb: 'img/khanjar-4-thumb.jpg' }, { id: 'khanjar-5', file: 'img/khanjar-5.jpg', thumb: 'img/khanjar-5-thumb.jpg' }, { id: 'khanjar-6', file: 'img/khanjar-6.jpg', thumb: 'img/khanjar-6-thumb.jpg' }, { id: 'khanjar-7', file: 'img/khanjar-7.jpg', thumb: 'img/khanjar-7-thumb.jpg' }, { id: 'khanjar-8', file: 'img/khanjar-8.jpg', thumb: 'img/khanjar-8-thumb.jpg' } ] },
  { id: 'doors', icon: '🚪', color: '#2F6D6A',
    name: { ar: 'الأبواب', fr: 'Portes', en: 'Doors' },
    images: [ { id: 'doors-1', file: 'img/doors-1.jpg', thumb: 'img/doors-1-thumb.jpg' }, { id: 'doors-2', file: 'img/doors-2.jpg', thumb: 'img/doors-2-thumb.jpg' }, { id: 'doors-3', file: 'img/doors-3.jpg', thumb: 'img/doors-3-thumb.jpg' }, { id: 'doors-4', file: 'img/doors-4.jpg', thumb: 'img/doors-4-thumb.jpg' }, { id: 'doors-5', file: 'img/doors-5.jpg', thumb: 'img/doors-5-thumb.jpg' }, { id: 'doors-6', file: 'img/doors-6.jpg', thumb: 'img/doors-6-thumb.jpg' }, { id: 'doors-7', file: 'img/doors-7.jpg', thumb: 'img/doors-7-thumb.jpg' }, { id: 'doors-8', file: 'img/doors-8.jpg', thumb: 'img/doors-8-thumb.jpg' } ] },
  { id: 'lanterns', icon: '🏮', color: '#7A3E8E',
    name: { ar: 'الفوانيس', fr: 'Lanternes', en: 'Lanterns' },
    images: [ { id: 'lanterns-1', file: 'img/lanterns-1.jpg', thumb: 'img/lanterns-1-thumb.jpg' }, { id: 'lanterns-2', file: 'img/lanterns-2.jpg', thumb: 'img/lanterns-2-thumb.jpg' }, { id: 'lanterns-3', file: 'img/lanterns-3.jpg', thumb: 'img/lanterns-3-thumb.jpg' }, { id: 'lanterns-4', file: 'img/lanterns-4.jpg', thumb: 'img/lanterns-4-thumb.jpg' }, { id: 'lanterns-5', file: 'img/lanterns-5.jpg', thumb: 'img/lanterns-5-thumb.jpg' }, { id: 'lanterns-6', file: 'img/lanterns-6.jpg', thumb: 'img/lanterns-6-thumb.jpg' }, { id: 'lanterns-7', file: 'img/lanterns-7.jpg', thumb: 'img/lanterns-7-thumb.jpg' }, { id: 'lanterns-8', file: 'img/lanterns-8.jpg', thumb: 'img/lanterns-8-thumb.jpg' } ] },
];

window.DIFFICULTIES = [
  { n: 3, label: '9' },
  { n: 4, label: '16' },
  { n: 6, label: '36' },
  { n: 8, label: '64' },
  { n: 10, label: '100' },
];
