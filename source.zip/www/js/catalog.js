// كتالوج المجموعات والتصاور. زيد تصويرة جديدة: حطها فـ img/ وزيدها هنا.
window.CATALOG = [
  { id: 'zellige', icon: '🟦', color: '#1F4E8C',
    name: { ar: 'الزليج', fr: 'Zellige', en: 'Zellige' },
    images: [ { id: 'zellige-1', file: 'img/zellige-1.jpg', thumb: 'img/zellige-1-thumb.jpg' } ] },
  { id: 'carpets', icon: '🧶', color: '#8E2B23',
    name: { ar: 'الزرابي', fr: 'Tapis', en: 'Carpets' },
    images: [ { id: 'carpet-1', file: 'img/carpet-1.jpg', thumb: 'img/carpet-1-thumb.jpg' } ] },
  { id: 'tajine', icon: '🏺', color: '#B5652B',
    name: { ar: 'الطاجين والفخار', fr: 'Tajines & poterie', en: 'Tajines & pottery' },
    images: [ { id: 'tajine-1', file: 'img/tajine-1.jpg', thumb: 'img/tajine-1-thumb.jpg' } ] },
  { id: 'khanjar', icon: '🗡️', color: '#5B6770',
    name: { ar: 'الخنجر والنحاس', fr: 'Khanjar & cuivre', en: 'Khanjar & brass' },
    images: [ { id: 'khanjar-1', file: 'img/khanjar-1.jpg', thumb: 'img/khanjar-1-thumb.jpg' } ] },
  { id: 'doors', icon: '🚪', color: '#2F6D6A',
    name: { ar: 'الأبواب', fr: 'Portes', en: 'Doors' },
    images: [ { id: 'doors-1', file: 'img/doors-1.jpg', thumb: 'img/doors-1-thumb.jpg' } ] },
  { id: 'lanterns', icon: '🏮', color: '#7A3E8E',
    name: { ar: 'الفوانيس', fr: 'Lanternes', en: 'Lanterns' },
    images: [ { id: 'lanterns-1', file: 'img/lanterns-1.jpg', thumb: 'img/lanterns-1-thumb.jpg' } ] },
];

window.DIFFICULTIES = [
  { n: 3, label: '9' },
  { n: 4, label: '16' },
  { n: 6, label: '36' },
  { n: 8, label: '64' },
  { n: 10, label: '100' },
];
