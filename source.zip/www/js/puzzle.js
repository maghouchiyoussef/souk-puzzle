// محرك البازل (Jigsaw) — Canvas بقطع كلاسيكية بالنتوءات
(function(){
  'use strict';

  function rand(seed){ // مولد عشوائي ثابت (باش القطع ما يتبدلوش ملي نرجعو للعبة)
    let s = seed >>> 0;
    return () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; };
  }

  // يرسم جانب واحد ديال القطعة من A إلى B، k=+1 نتوء للخارج، -1 للداخل، 0 مستقيم
  function side(p, ax, ay, bx, by, k, s){
    if(!k){ p.lineTo(bx, by); return; }
    const dx = (bx-ax)/s, dy = (by-ay)/s; // اتجاه
    const nx = dy, ny = -dx;              // العمودي للخارج (مع اتجاه عقارب الساعة)
    const H = 0.30 * s * k;
    const P = (u, v) => [ax + dx*u*s + nx*v*H, ay + dy*u*s + ny*v*H];
    const L = (u,v) => { const q = P(u,v); p.lineTo(q[0], q[1]); };
    const C = (u1,v1,u2,v2,u3,v3) => { const a=P(u1,v1), b=P(u2,v2), c=P(u3,v3); p.bezierCurveTo(a[0],a[1],b[0],b[1],c[0],c[1]); };
    L(0.37, 0);
    C(0.40, 0.05, 0.42, 0.15, 0.40, 0.25);
    C(0.36, 0.45, 0.36, 0.82, 0.50, 0.82);
    C(0.64, 0.82, 0.64, 0.45, 0.60, 0.25);
    C(0.58, 0.15, 0.60, 0.05, 0.63, 0);
    L(1, 0);
  }

  function piecePath(s, ox, oy, sides){
    const p = new Path2D();
    p.moveTo(ox, oy);
    side(p, ox, oy, ox+s, oy, sides.top, s);
    side(p, ox+s, oy, ox+s, oy+s, sides.right, s);
    side(p, ox+s, oy+s, ox, oy+s, sides.bottom, s);
    side(p, ox, oy+s, ox, oy, sides.left, s);
    p.closePath();
    return p;
  }

  class Puzzle {
    constructor(canvas, img, n, opts){
      this.cv = canvas; this.ctx = canvas.getContext('2d');
      this.img = img; this.n = n; this.opts = opts || {};
      this.dpr = Math.min(window.devicePixelRatio || 1, 2.5);
      this.preview = false; this.edgesOnly = false;
      this.drag = null; this.dirty = true; this.done = false;
      const saved = this.opts.saved;
      this.seed = saved ? saved.seed : (Math.random()*1e9)|0;
      this.elapsed = saved ? saved.elapsed : 0;
      this.buildEdges();
      this.pieces = [];
      for(let r=0;r<n;r++) for(let c=0;c<n;c++){
        this.pieces.push({ r, c, i: r*n+c, sides: this.sidesOf(r,c), nx: 0, ny: 0, locked: false });
      }
      this.layout();
      if(saved && saved.pieces && saved.pieces.length === this.pieces.length){
        saved.pieces.forEach((sp, i) => { Object.assign(this.pieces[i], { nx: sp[0], ny: sp[1], locked: !!sp[2] }); });
        this.order = saved.order || this.pieces.map(p => p.i);
      } else {
        this.scatter();
      }
      this.bind();
      this.loop();
    }

    buildEdges(){
      const n = this.n, R = rand(this.seed);
      this.h = []; this.v = [];
      for(let r=0;r<n-1;r++){ this.h.push([]); for(let c=0;c<n;c++) this.h[r].push(R()<0.5?1:-1); }
      for(let r=0;r<n;r++){ this.v.push([]); for(let c=0;c<n-1;c++) this.v[r].push(R()<0.5?1:-1); }
    }
    sidesOf(r,c){
      const n=this.n;
      return {
        top: r===0 ? 0 : -this.h[r-1][c],
        bottom: r===n-1 ? 0 : this.h[r][c],
        left: c===0 ? 0 : -this.v[r][c-1],
        right: c===n-1 ? 0 : this.v[r][c],
      };
    }
    isEdge(p){ return p.r===0 || p.c===0 || p.r===this.n-1 || p.c===this.n-1; }

    layout(){
      const rect = this.cv.getBoundingClientRect();
      this.W = rect.width; this.H = rect.height;
      this.cv.width = Math.round(this.W*this.dpr); this.cv.height = Math.round(this.H*this.dpr);
      const B = Math.floor(Math.min(this.W - 24, this.H * 0.58));
      this.B = B; this.bx = Math.round((this.W - B)/2); this.by = 12;
      this.s = B / this.n; this.m = Math.ceil(this.s * 0.26);
      this.renderPieces();
      this.dirty = true;
    }

    renderPieces(){
      const { s, m, dpr, img, B } = this;
      const sc = img.naturalWidth / B;
      const size = s + 2*m;
      for(const p of this.pieces){
        const c = document.createElement('canvas');
        c.width = Math.ceil(size*dpr); c.height = Math.ceil(size*dpr);
        const g = c.getContext('2d');
        g.scale(dpr, dpr);
        const path = piecePath(s, m, m, p.sides);
        g.save();
        g.clip(path);
        g.drawImage(img, (p.c*s - m)*sc, (p.r*s - m)*sc, size*sc, size*sc, 0, 0, size, size);
        // لمسة ضوء خفيفة باش تبان القطعة بارزة
        const grd = g.createLinearGradient(0, 0, size, size);
        grd.addColorStop(0, 'rgba(255,255,255,0.10)'); grd.addColorStop(1, 'rgba(0,0,0,0.12)');
        g.fillStyle = grd; g.fillRect(0, 0, size, size);
        g.restore();
        g.lineWidth = 1.2; g.strokeStyle = 'rgba(0,0,0,0.45)'; g.stroke(path);
        g.lineWidth = 0.8; g.strokeStyle = 'rgba(255,255,255,0.25)'; g.stroke(path);
        p.canvas = c;
        p.path = piecePath(s, 0, 0, p.sides); // للمس (hit test) بالنسبة لركن القطعة
      }
    }

    // تحويل بين الإحداثيات النسبية (بوحدة القطعة) والشاشة
    toScreen(p){ return [this.bx + p.nx*this.s, this.by + p.ny*this.s]; }
    fromScreen(x,y){ return [(x - this.bx)/this.s, (y - this.by)/this.s]; }

    scatter(){
      const { W, H, s, B, by } = this;
      const R = rand(this.seed ^ 0x9e3779b9);
      let x0 = 6, x1 = W - s - 6, y0 = by + B + 10, y1 = H - s - 6;
      if(y1 - y0 < s*0.8){ y0 = 6; y1 = H - s - 6; }
      const ids = this.pieces.map(p=>p.i).sort(() => R() - 0.5);
      this.order = ids;
      for(const p of this.pieces){
        const x = x0 + R()*(Math.max(0, x1-x0));
        const y = y0 + R()*(Math.max(0, y1-y0));
        [p.nx, p.ny] = this.fromScreen(x, y);
        p.locked = false;
      }
      this.dirty = true;
    }

    clampPiece(p){
      const [x,y] = this.toScreen(p);
      const cx = Math.min(Math.max(x, -this.s*0.3), this.W - this.s*0.7);
      const cy = Math.min(Math.max(y, -this.s*0.3), this.H - this.s*0.7);
      [p.nx, p.ny] = this.fromScreen(cx, cy);
    }

    bind(){
      const cv = this.cv;
      this._down = (e) => this.onDown(e);
      this._move = (e) => this.onMove(e);
      this._up = (e) => this.onUp(e);
      this._resize = () => { this.layout(); this.pieces.forEach(p=>{ if(!p.locked) this.clampPiece(p); }); };
      cv.addEventListener('pointerdown', this._down);
      window.addEventListener('pointermove', this._move);
      window.addEventListener('pointerup', this._up);
      window.addEventListener('pointercancel', this._up);
      window.addEventListener('resize', this._resize);
      this.startTime = performance.now();
      this.timer = setInterval(() => {
        if(this.done || document.hidden) return;
        this.elapsed++; this.opts.onTick && this.opts.onTick(this.elapsed);
        if(this.elapsed % 5 === 0) this.save();
      }, 1000);
    }
    destroy(){
      const cv = this.cv;
      cv.removeEventListener('pointerdown', this._down);
      window.removeEventListener('pointermove', this._move);
      window.removeEventListener('pointerup', this._up);
      window.removeEventListener('pointercancel', this._up);
      window.removeEventListener('resize', this._resize);
      clearInterval(this.timer);
      this.stopped = true;
    }

    pos(e){ const r = this.cv.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; }

    visible(p){ return !p.locked && !p.placing && (!this.edgesOnly || this.isEdge(p)); }

    hit(x, y){
      const ctx = this.ctx;
      ctx.setTransform(1,0,0,1,0,0);
      for(let k = this.order.length - 1; k >= 0; k--){
        const p = this.pieces[this.order[k]];
        if(!this.visible(p)) continue;
        const [px, py] = this.toScreen(p);
        const lx = x - px, ly = y - py;
        if(lx < -this.m || ly < -this.m || lx > this.s + this.m || ly > this.s + this.m) continue;
        // نوسعو منطقة اللمس شوية للقطع الصغار
        if(ctx.isPointInPath(p.path, lx, ly) || (this.s < 44 && lx > -6 && ly > -6 && lx < this.s+6 && ly < this.s+6)) return p;
      }
      return null;
    }

    onDown(e){
      if(this.done) return;
      const [x,y] = this.pos(e);
      const p = this.hit(x,y);
      if(!p) return;
      e.preventDefault();
      const [px,py] = this.toScreen(p);
      this.drag = { p, dx: x - px, dy: y - py, id: e.pointerId };
      this.order = this.order.filter(i => i !== p.i).concat(p.i);
      this.opts.onPick && this.opts.onPick();
      this.dirty = true;
    }
    onMove(e){
      if(!this.drag || e.pointerId !== this.drag.id) return;
      const [x,y] = this.pos(e);
      // نرفعو القطعة شوية فوق الصبع باش تبان
      [this.drag.p.nx, this.drag.p.ny] = this.fromScreen(x - this.drag.dx, y - this.drag.dy);
      this.dirty = true;
    }
    onUp(e){
      if(!this.drag || e.pointerId !== this.drag.id) return;
      const p = this.drag.p; this.drag = null;
      const dx = (p.nx - p.c) * this.s, dy = (p.ny - p.r) * this.s;
      if(Math.hypot(dx, dy) < Math.max(14, this.s * 0.28)){
        this.lock(p);
      } else {
        this.clampPiece(p);
      }
      this.dirty = true;
      this.save();
    }

    lock(p, animate){
      p.nx = p.c; p.ny = p.r; p.locked = true;
      this.order = [p.i].concat(this.order.filter(i => i !== p.i)); // القطع المركبة تحت
      this.flash = { p, t: performance.now() };
      this.opts.onSnap && this.opts.onSnap(this.remaining());
      if(this.remaining() === 0){
        this.done = true;
        this.winAt = performance.now();
        this.save();
        setTimeout(() => this.opts.onWin && this.opts.onWin(this.elapsed), 900);
      }
    }

    remaining(){ return this.pieces.filter(p => !p.locked).length; }

    // تلميح: يركّب قطعة وحدة أوتوماتيكيًا (كنبداو بالحواشي)
    placeOne(){
      const free = this.pieces.filter(p => !p.locked && !p.placing);
      if(!free.length) return;
      const pick = free.find(p => this.isEdge(p)) || free[0];
      pick.placing = true;
      const from = this.toScreen(pick); const to = [this.bx + pick.c*this.s, this.by + pick.r*this.s];
      const t0 = performance.now(), D = 450;
      this.order = this.order.filter(i => i !== pick.i).concat(pick.i);
      const step = (t) => {
        const k = Math.min(1, (t - t0)/D), e = 1 - Math.pow(1-k, 3);
        [pick.nx, pick.ny] = this.fromScreen(from[0] + (to[0]-from[0])*e, from[1] + (to[1]-from[1])*e);
        this.dirty = true;
        if(k < 1) requestAnimationFrame(step); else { pick.placing = false; this.lock(pick); this.save(); }
      };
      requestAnimationFrame(step);
    }

    setPreview(v){ this.preview = v; this.dirty = true; }
    setEdgesOnly(v){ this.edgesOnly = v; this.dirty = true; }
    reshuffle(){
      const R = Math.random;
      const { W, H, s, B, by } = this;
      let y0 = by + B + 10, y1 = H - s - 6;
      if(y1 - y0 < s*0.8){ y0 = 6; }
      for(const p of this.pieces){ if(p.locked) continue;
        [p.nx, p.ny] = this.fromScreen(6 + R()*(W - s - 12), y0 + R()*Math.max(0, y1-y0)); }
      this.dirty = true; this.save();
    }

    save(){
      if(!this.opts.onSave) return;
      this.opts.onSave({
        seed: this.seed, elapsed: this.elapsed, order: this.order,
        pieces: this.pieces.map(p => [Math.round(p.nx*1000)/1000, Math.round(p.ny*1000)/1000, p.locked ? 1 : 0]),
      });
    }

    loop(){
      if(this.stopped) return;
      if(this.dirty || this.flash || (this.done && this.winAt)) this.draw();
      requestAnimationFrame(() => this.loop());
    }

    draw(){
      this.dirty = false;
      const { ctx, dpr, W, H, bx, by, B, s, m } = this;
      ctx.setTransform(dpr,0,0,dpr,0,0);
      ctx.clearRect(0,0,W,H);

      // اللوحة
      ctx.save();
      ctx.shadowColor = 'rgba(0,0,0,0.35)'; ctx.shadowBlur = 18;
      ctx.fillStyle = '#1b1426';
      ctx.fillRect(bx-4, by-4, B+8, B+8);
      ctx.restore();
      ctx.save();
      ctx.globalAlpha = this.preview ? 0.45 : 0.10;
      ctx.drawImage(this.img, bx, by, B, B);
      ctx.restore();
      // خطوط الشبكة الخفيفة
      if(!this.done){
        ctx.strokeStyle = 'rgba(255,255,255,0.06)'; ctx.lineWidth = 1;
        for(let i=1;i<this.n;i++){
          ctx.beginPath(); ctx.moveTo(bx + i*s, by); ctx.lineTo(bx + i*s, by + B); ctx.stroke();
          ctx.beginPath(); ctx.moveTo(bx, by + i*s); ctx.lineTo(bx + B, by + i*s); ctx.stroke();
        }
      }
      ctx.strokeStyle = 'rgba(216,168,74,0.55)'; ctx.lineWidth = 2;
      ctx.strokeRect(bx-4, by-4, B+8, B+8);

      // القطع المركبة
      for(const i of this.order){
        const p = this.pieces[i];
        if(!p.locked) continue;
        const [x,y] = this.toScreen(p);
        ctx.drawImage(p.canvas, x - m, y - m, s + 2*m, s + 2*m);
      }
      // ملي تكمل اللعبة: التصويرة كاملة بلا خطوط
      if(this.done){
        const k = Math.min(1, (performance.now() - this.winAt)/700);
        ctx.save(); ctx.globalAlpha = k; ctx.drawImage(this.img, bx, by, B, B); ctx.restore();
        if(k < 1) this.dirty = true; else this.winAt = null;
      }
      // القطع الحرة
      for(const i of this.order){
        const p = this.pieces[i];
        if(!this.visible(p)) continue;
        const [x,y] = this.toScreen(p);
        const lifted = this.drag && this.drag.p === p;
        ctx.save();
        ctx.shadowColor = 'rgba(0,0,0,0.5)';
        ctx.shadowBlur = lifted ? 16 : 5; ctx.shadowOffsetY = lifted ? 6 : 2;
        const sc = lifted ? 1.06 : 1;
        const sz = (s + 2*m) * sc;
        ctx.drawImage(p.canvas, x + s/2 - sz/2, y + s/2 - sz/2, sz, sz);
        ctx.restore();
      }
      // لمعة ملي كتتركب قطعة
      if(this.flash){
        const k = (performance.now() - this.flash.t)/450;
        if(k >= 1){ this.flash = null; }
        else {
          const [x,y] = this.toScreen(this.flash.p);
          ctx.save();
          ctx.globalCompositeOperation = 'lighter';
          ctx.globalAlpha = 0.45 * (1-k);
          ctx.translate(x - m, y - m);
          ctx.fillStyle = '#ffd98a';
          const pp = piecePath(s, m, m, this.flash.p.sides);
          ctx.fill(pp);
          ctx.restore();
        }
      }
    }
  }

  window.Puzzle = Puzzle;
})();
