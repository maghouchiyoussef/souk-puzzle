(function(){
  const T = {
    ar: {
      title: 'بازل السوق', subtitle: 'ركّب كنوز الصناعة التقليدية المغربية',
      collections: 'المجموعات', soon: 'قريبًا', pieces: 'قطعة', chooseDiff: 'اختر عدد القطع',
      play: 'العب', resume: 'كمّل', done: 'مكتمل', left: 'باقي', time: 'الوقت',
      congrats: 'تبارك الله! كمّلتي البازل', next: 'التالي', again: 'عاود', home: 'الرئيسية',
      hintAd: 'شاهد إعلان لوضع قطعة', noHint: 'ما كاينش إعلان دابا، جرب من بعد',
      edges: 'الحواشي', preview: 'المعاينة', settings: 'الإعدادات', sound: 'الأصوات',
      vibrate: 'الاهتزاز', music: 'الموسيقى', privacy: 'سياسة الخصوصية', privacyOpts: 'خيارات الخصوصية والإعلانات',
      language: 'اللغة', completed: 'كمّلتي', of: 'من', best: 'أحسن وقت', unlockAd: 'افتح بإعلان', daily: 'بازل اليوم',
    },
    fr: {
      title: 'Souk Puzzle', subtitle: "Assemblez les trésors de l'artisanat marocain",
      collections: 'Collections', soon: 'Bientôt', pieces: 'pièces', chooseDiff: 'Nombre de pièces',
      play: 'Jouer', resume: 'Reprendre', done: 'Terminé', left: 'Restantes', time: 'Temps',
      congrats: 'Bravo ! Puzzle terminé', next: 'Suivant', again: 'Rejouer', home: 'Accueil',
      hintAd: 'Regarder une pub pour placer une pièce', noHint: "Pas de pub disponible, réessayez",
      edges: 'Bords', preview: 'Aperçu', settings: 'Réglages', sound: 'Sons',
      vibrate: 'Vibration', music: 'Musique', privacy: 'Confidentialité', privacyOpts: 'Options de confidentialité',
      language: 'Langue', completed: 'Terminés', of: 'sur', best: 'Meilleur temps', unlockAd: 'Débloquer (pub)', daily: 'Puzzle du jour',
    },
    en: {
      title: 'Souk Puzzle', subtitle: 'Piece together the treasures of Moroccan craft',
      collections: 'Collections', soon: 'Coming soon', pieces: 'pieces', chooseDiff: 'Choose pieces',
      play: 'Play', resume: 'Resume', done: 'Done', left: 'Left', time: 'Time',
      congrats: 'Well done! Puzzle complete', next: 'Next', again: 'Replay', home: 'Home',
      hintAd: 'Watch an ad to place a piece', noHint: 'No ad available right now, try later',
      edges: 'Edges', preview: 'Preview', settings: 'Settings', sound: 'Sounds',
      vibrate: 'Vibration', music: 'Music', privacy: 'Privacy policy', privacyOpts: 'Privacy & ad options',
      language: 'Language', completed: 'Completed', of: 'of', best: 'Best time', unlockAd: 'Unlock (ad)', daily: 'Daily puzzle',
    },
  };
  function detect(){
    try{ const s = localStorage.getItem('souk_lang'); if(s && T[s]) return s; }catch(e){}
    const l = (navigator.language || 'en').slice(0,2);
    return T[l] ? l : 'en';
  }
  let lang = detect();
  window.I18N = {
    get lang(){ return lang; },
    set(l){ if(!T[l]) return; lang = l; try{ localStorage.setItem('souk_lang', l); }catch(e){} apply(); },
    t(k){ return (T[lang] && T[lang][k]) || T.en[k] || k; },
    name(obj){ return obj[lang] || obj.en; },
  };
  function apply(){
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    document.querySelectorAll('[data-i18n]').forEach(el => { el.textContent = I18N.t(el.dataset.i18n); });
    document.dispatchEvent(new CustomEvent('lang-changed'));
  }
  window.I18N.apply = apply;
})();
