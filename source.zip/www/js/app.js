(function(){
  'use strict';
  const $ = (id) => document.getElementById(id);
  const t = (k) => I18N.t(k);

  // ---------- Storage ----------
  const S = {
    get(k, d){ try{ const v = localStorage.getItem(k); return v === null ? d : JSON.parse(v); }catch(e){ return d; } },
    set(k, v){ try{ localStorage.setItem(k, JSON.stringify(v)); }catch(e){} },
    del(k){ try{ localStorage.removeItem(k); }catch(e){} },
  };
  const doneKey = (img, n) => `souk_done_${img}_${n}`;
  const saveKey = (img, n) => `souk_save_${img}_${n}`;
  const isDone = (img, n) => !!S.get(doneKey(img, n), null);
  const imgDoneAny = (img) => DIFFICULTIES.some(d => isDone(img, d.n));

  const allImages = () => CATALOG.flatMap(c => c.images.map(im => ({ ...im, coll: c })));

  // ---------- Screens ----------
  let screen = 'home', currentColl = null, game = null, current = null;
  function show(name){
    screen = name;
    ['home','coll','game'].forEach(s => $('screen-' + s).classList.toggle('active', s === name));
    if(name === 'game') Ads.hideBanner(); else Ads.showBanner();
  }
  let toastT = null;
  function toast(msg){ const el = $('toast'); el.textContent = msg; el.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(() => el.classList.remove('show'), 2200); }
  const fmt = (s) => `${Math.floor(s/60)}:${String(s%60).padStart(2,'0')}`;

  // ---------- Home ----------
  function dailyImage(){
    const imgs = allImages(); if(!imgs.length) return null;
    const d = new Date(); const k = d.getFullYear()*372 + d.getMonth()*31 + d.getDate();
    return imgs[k % imgs.length];
  }
  function renderHome(){
    const di = dailyImage();
    if(di){ $('daily-img').src = di.file; }
    const g = $('coll-grid'); g.innerHTML = '';
    for(const c of CATALOG){
      const el = document.createElement('div');
      const locked = !c.images.length;
      el.className = 'coll' + (locked ? ' locked' : '');
      const doneCount = c.images.filter(im => imgDoneAny(im.id)).length;
      el.innerHTML = (locked ? `<div class="ph" style="background:${c.color}">${c.icon}</div><span class="soon">${t('soon')}</span>`
                             : `<img src="${c.images[0].thumb}" alt="">`) +
        `<div class="cap"><b>${c.icon} ${I18N.name(c.name)}</b><small>${locked ? '' : `${t('completed')} ${doneCount} ${t('of')} ${c.images.length}`}</small></div>`;
      el.addEventListener('click', () => { FX.tap(); if(locked){ toast(t('soon')); return; } openColl(c); });
      g.appendChild(el);
    }
  }
  $('daily').addEventListener('click', () => { const di = dailyImage(); if(di){ FX.tap(); openDiff(di); } });

  // ---------- Collection ----------
  function openColl(c){
    currentColl = c;
    $('coll-title').textContent = `${c.icon} ${I18N.name(c.name)}`;
    const g = $('img-grid'); g.innerHTML = '';
    for(const im of c.images){
      const done = DIFFICULTIES.filter(d => isDone(im.id, d.n)).length;
      const el = document.createElement('div');
      el.className = 'img-card';
      el.innerHTML = `<img src="${im.thumb}" alt=""><span class="badge ${done ? 'ok' : ''}">${done ? '✓ ' + done + '/' + DIFFICULTIES.length : '🧩'}</span>`;
      el.addEventListener('click', () => { FX.tap(); openDiff({ ...im, coll: c }); });
      g.appendChild(el);
    }
    show('coll');
  }
  $('coll-back').addEventListener('click', () => { FX.tap(); renderHome(); show('home'); });

  // ---------- Difficulty sheet ----------
  function openSheet(id){ $('veil').classList.add('show'); $(id).classList.add('show'); }
  function closeSheets(){ $('veil').classList.remove('show'); document.querySelectorAll('.sheet').forEach(s => s.classList.remove('show')); }
  $('veil').addEventListener('click', closeSheets);
  const sheetOpen = () => !!document.querySelector('.sheet.show');

  function openDiff(im){
    $('diff-prev').src = im.thumb;
    const row = $('diff-row'); row.innerHTML = '';
    for(const d of DIFFICULTIES){
      const b = document.createElement('div');
      b.className = 'diff' + (isDone(im.id, d.n) ? ' done' : '') + (S.get(saveKey(im.id, d.n), null) ? ' saved' : '');
      b.innerHTML = `<b>${d.label}</b><small>${t('pieces')}</small>`;
      b.addEventListener('click', () => { FX.tap(); closeSheets(); startGame(im, d.n); });
      row.appendChild(b);
    }
    openSheet('diff-sheet');
  }

  // ---------- Game ----------
  function startGame(im, n){
    current = { im, n };
    show('game');
    const img = new Image();
    img.onload = () => {
      if(game) game.destroy();
      $('t-preview').querySelector('.icon-btn').classList.remove('on');
      $('t-edges').querySelector('.icon-btn').classList.remove('on');
      game = new Puzzle($('board'), img, n, {
        saved: S.get(saveKey(im.id, n), null),
        onSave: (st) => S.set(saveKey(im.id, n), st),
        onTick: (s) => { $('g-time').textContent = fmt(s); },
        onPick: () => FX.pick(),
        onSnap: (left) => { FX.snap(); $('g-left').textContent = left; },
        onWin: (secs) => win(secs),
      });
      window.__game = game; // للتجربة
      $('g-time').textContent = fmt(game.elapsed);
      $('g-left').textContent = game.remaining();
      if(game.remaining() === 0){ S.del(saveKey(im.id, n)); game.destroy(); game = null; startGame(im, n); }
    };
    img.src = im.file;
  }
  function leaveGame(){
    if(game){ game.save(); game.destroy(); game = null; }
    if(currentColl){ openColl(currentColl); } else { renderHome(); show('home'); }
  }
  $('game-back').addEventListener('click', () => { FX.tap(); leaveGame(); });

  $('t-preview').addEventListener('click', () => {
    if(!game) return; FX.tap();
    const b = $('t-preview').querySelector('.icon-btn'); b.classList.toggle('on'); game.setPreview(b.classList.contains('on'));
  });
  $('t-edges').addEventListener('click', () => {
    if(!game) return; FX.tap();
    const b = $('t-edges').querySelector('.icon-btn'); b.classList.toggle('on'); game.setEdgesOnly(b.classList.contains('on'));
  });
  $('t-shuffle').addEventListener('click', () => { if(!game) return; FX.tap(); game.reshuffle(); });
  $('t-hint').addEventListener('click', async () => {
    if(!game || game.done) return;
    if(!Ads.isNative){ FX.lifeline(); game.placeOne(); return; } // على الويب: بلا إعلان (للتجربة)
    if(!Ads.rewardedAvailable()){ toast(t('noHint')); return; }
    const ok = await Ads.showRewarded();
    if(ok && game){ FX.lifeline(); game.placeOne(); }
  });

  // ---------- Win ----------
  function win(secs){
    const { im, n } = current;
    const prev = S.get(doneKey(im.id, n), null);
    S.set(doneKey(im.id, n), { best: prev ? Math.min(prev.best, secs) : secs });
    S.del(saveKey(im.id, n));
    FX.win();
    $('win-img').src = im.file;
    $('win-time').textContent = fmt(secs);
    $('win-pieces').textContent = n*n;
    $('win').classList.add('show');
    confetti();
  }
  function nextTarget(){
    const { im, n } = current;
    const list = (im.coll || CATALOG.find(c => c.images.some(x => x.id === im.id))).images;
    const idx = list.findIndex(x => x.id === im.id);
    const nextIm = list[(idx + 1) % list.length];
    if(nextIm.id !== im.id) return { im: { ...nextIm, coll: im.coll }, n };
    const di = DIFFICULTIES.findIndex(d => d.n === n);
    return { im, n: DIFFICULTIES[Math.min(di + 1, DIFFICULTIES.length - 1)].n };
  }
  $('win-next').addEventListener('click', async () => {
    FX.tap(); $('win').classList.remove('show');
    await Ads.maybeInterstitial();
    const nt = nextTarget(); startGame(nt.im, nt.n);
  });
  $('win-home').addEventListener('click', async () => {
    FX.tap(); $('win').classList.remove('show');
    await Ads.maybeInterstitial();
    if(game){ game.destroy(); game = null; }
    renderHome(); show('home');
  });

  function confetti(){
    const cv = $('confetti'), ctx = cv.getContext('2d');
    const W = cv.width = innerWidth, H = cv.height = innerHeight;
    const cols = ['#d8a84a','#c4622d','#2f8f8a','#1f4e8c','#f5efe6','#8e2b23'];
    const parts = Array.from({length: 120}, () => ({ x: W/2, y: H/3, vx: (Math.random()-0.5)*12, vy: -Math.random()*12-4,
      s: 4+Math.random()*6, c: cols[(Math.random()*cols.length)|0], r: Math.random()*6, vr: (Math.random()-0.5)*0.3 }));
    const t0 = performance.now();
    (function f(now){
      ctx.clearRect(0,0,W,H);
      for(const p of parts){ p.vy += 0.35; p.x += p.vx; p.y += p.vy; p.r += p.vr;
        ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.r); ctx.fillStyle = p.c; ctx.fillRect(-p.s/2, -p.s/2, p.s, p.s*0.6); ctx.restore(); }
      if(now - t0 < 2600) requestAnimationFrame(f); else ctx.clearRect(0,0,W,H);
    })(t0);
  }

  // ---------- Settings ----------
  function syncSettings(){
    $('sw-sound').classList.toggle('on', FX.settings.sound);
    $('sw-vib').classList.toggle('on', FX.settings.vibrate);
    document.querySelectorAll('#langs button').forEach(b => b.classList.toggle('on', b.dataset.l === I18N.lang));
    $('row-privacy-opts').style.display = Ads.privacyRequired ? '' : 'none';
  }
  $('settings-btn').addEventListener('click', () => { FX.tap(); syncSettings(); openSheet('set-sheet'); });
  $('sw-sound').addEventListener('click', () => { FX.settings.sound = !FX.settings.sound; syncSettings(); FX.tap(); });
  $('sw-vib').addEventListener('click', () => { FX.settings.vibrate = !FX.settings.vibrate; syncSettings(); FX.tap(); });
  document.querySelectorAll('#langs button').forEach(b => b.addEventListener('click', () => { I18N.set(b.dataset.l); syncSettings(); FX.tap(); }));
  $('privacy-opts').addEventListener('click', () => Ads.showPrivacyOptions());
  document.addEventListener('lang-changed', () => { renderHome(); if(screen === 'coll' && currentColl) openColl(currentColl); });

  // ---------- Native ----------
  const N = window.Native;
  if(N && N.isNative){
    try{ N.StatusBar.setStyle({ style: N.Style.Dark }); N.StatusBar.setBackgroundColor({ color: '#160f22' }); }catch(e){}
    try{
      N.App.addListener('backButton', () => {
        if($('win').classList.contains('show')){ $('win-home').click(); }
        else if(sheetOpen()) closeSheets();
        else if(screen === 'game') leaveGame();
        else if(screen === 'coll'){ renderHome(); show('home'); }
        else N.App.exitApp();
      });
      N.App.addListener('pause', () => { if(game) game.save(); });
    }catch(e){}
  }

  // ---------- Init ----------
  I18N.apply();
  renderHome();
  Ads.init().finally(() => {
    if(screen !== 'game') Ads.showBanner();
    try{ N && N.isNative && N.SplashScreen.hide(); }catch(e){}
  });
})();
