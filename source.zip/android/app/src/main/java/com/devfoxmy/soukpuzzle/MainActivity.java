package com.devfoxmy.soukpuzzle;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
