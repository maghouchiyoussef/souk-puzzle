#!/usr/bin/env python3
"""Add an image to a collection.

Usage:
  tools/add-image.py <collection> <path> [<path> ...]
  tools/add-image.py <collection> <folder>

Crops each image to a centered square, writes www/img/<prefix>-<k>.jpg (1024px)
and www/img/<prefix>-<k>-thumb.jpg (256px), and registers it in www/js/catalog.js.
Requires Pillow (pip install pillow).
"""
import re
import sys
from pathlib import Path

from PIL import Image, ImageOps

ROOT = Path(__file__).resolve().parent.parent
IMG_DIR = ROOT / 'www' / 'img'
CATALOG = ROOT / 'www' / 'js' / 'catalog.js'
EXTS = {'.jpg', '.jpeg', '.png', '.webp'}


def square(im, size):
    im = ImageOps.exif_transpose(im).convert('RGB')
    w, h = im.size
    s = min(w, h)
    im = im.crop(((w - s) // 2, (h - s) // 2, (w - s) // 2 + s, (h - s) // 2 + s))
    return im.resize((size, size), Image.LANCZOS)


def collection_block(src, coll):
    m = re.search(r"\{\s*id:\s*'%s'.*?images:\s*\[(.*?)\]\s*\}" % re.escape(coll), src, re.S)
    if not m:
        ids = re.findall(r"\{\s*id:\s*'([\w-]+)',\s*icon:", src)
        sys.exit(f"Unknown collection '{coll}'. Available: {', '.join(ids)}")
    return m


def prefix_of(images_src, coll):
    # Reuse the existing prefix (e.g. 'carpet' for collection 'carpets')
    m = re.search(r"id:\s*'([\w-]+?)-\d+'", images_src)
    return m.group(1) if m else coll


def add(coll, path):
    src = CATALOG.read_text(encoding='utf-8')
    m = collection_block(src, coll)
    images_src = m.group(1)
    prefix = prefix_of(images_src, coll)
    used = [int(k) for k in re.findall(r"id:\s*'%s-(\d+)'" % re.escape(prefix), images_src)]
    k = max(used, default=0) + 1
    name = f'{prefix}-{k}'

    with Image.open(path) as im:
        if min(im.size) < 1024:
            print(f'  warning: {path.name} is {im.size[0]}x{im.size[1]}, will be upscaled')
        square(im, 1024).save(IMG_DIR / f'{name}.jpg', quality=85, optimize=True, progressive=True)
        square(im, 256).save(IMG_DIR / f'{name}-thumb.jpg', quality=80, optimize=True)

    entry = f"{{ id: '{name}', file: 'img/{name}.jpg', thumb: 'img/{name}-thumb.jpg' }}"
    body = images_src.rstrip()
    indent = '      '
    new_images = (f'\n{indent}' + f',\n{indent}'.join(
        [e.strip() for e in re.findall(r"\{[^{}]*\}", body)] + [entry]) + '\n    ')
    src = src[:m.start(1)] + new_images + src[m.end(1):]
    CATALOG.write_text(src, encoding='utf-8')
    print(f'  added {name} <- {path.name}')


def main():
    if len(sys.argv) < 3:
        sys.exit(__doc__)
    coll = sys.argv[1]
    paths = []
    for a in sys.argv[2:]:
        p = Path(a)
        if p.is_dir():
            paths += sorted(f for f in p.iterdir() if f.suffix.lower() in EXTS)
        elif p.is_file():
            paths.append(p)
        else:
            sys.exit(f'Not found: {a}')
    for p in paths:
        add(coll, p)


if __name__ == '__main__':
    main()
